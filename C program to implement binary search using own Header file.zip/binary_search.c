/*  201900307
    Rishabh Chauhan
*/

#include <stdio.h>
#include "myheader.h"

int main(){
    int n,s;
    //taking input from user
    printf("Enter the no.of elements: \n"); 
    scanf("%d",&n);
    int arr[n];
    printf("Enter the elements\n");
    for(int a=0; a<n ; a++){
        scanf("%d",&arr[a]);
    }
    printf("\nEnter the element you want to search: \n");
    scanf("%d",&s);
    binarySearch(s,n,arr);
  
    return 0;
}