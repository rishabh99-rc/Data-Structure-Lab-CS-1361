void swap( int *a, int *b);
void binarySearch(int search,int num,int arr[500]){
    
    //sorting 
    for(int i=0; i<num-1 ; i++){
        for(int j=0 ; j<num-1 ; j++){
            if(arr[j] > arr[j+1]){
                swap(&arr[j],&arr[j+1]);
            }
        }
    }
     printf("The sorted elements are:\n");
      for(int a=0; a<num ; a++){
        printf("%d ",arr[a]);
    }
    
    //binary search
    int high=num-1;
    int low=0;
    int flag=0;
    int mid;
    
    while(low<=high){
        mid=(high+low)/2;
        
        if(search>arr[mid]){
            low=mid+1;
        }
        if(search<arr[mid]){
            high=mid-1;
        }
        if(search==arr[mid]){
            printf("\nThe number %d found at %d position when 1st position is given to the first element",search,mid+1);
            flag=1;
            break;
        }
    }	 	  	 	   	      	    	  	 	
    if(flag==0){
        printf("\nNumber not found");
        
    }
}

//swap function

void swap( int *a, int *b){
    int temp=0;
    temp=*a;
    *a=*b;
    *b=temp;
}