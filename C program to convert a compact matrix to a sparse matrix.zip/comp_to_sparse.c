/*
 Registration Number : 201900307 (Rishabh Chauhan)
 
 Algorithm: 
 STEP 0 : Start
 
 STEP 1 : Declare 2-D matrix named as compt_matx[6][3]
 
 STEP 2 : Intialize compt_matx[6][3]
 
 STEP 3 : Display compt_matx[6][3]
 
 STEP 4 : Declare row_sparce = compt_matx[5][0] + 1 ,column_sparce = 0 , a = 0 
 
 STEP 5 : for(i=0 until i=6)
          5.1 : if(a < compt_matx[i][1])
              5.1.1 : a <-- compt_matx[i][1]
              
 STEP 6 : Store column_sparce as a+1
 
 STEP 7 : Declare sparce_matrix[row_sparce][column_sparce]
 
 STEP 8 : for(i=0 to row_sparce)
         8.1 : for(j=0 to column_sparce)
             8.1.1 : sparce_matrix[i][j] <-- 0
             
 STEP 9 : for( i=0 until i=6)
         9.1 :  Declare row =0 , column = 0 ,value = 0
         9.2 :  row <-- compt_matrix[i][0]
         9.3 :  column <-- compt_matrix[i][1]
         9.4 :  value <-- compt_matrix[i][2]
         9.5 :  sparce_matrix[row][column] <-- value
         
 STEP 10 : Display sparce_matrix
 
 STEP 11 : Stop
*/

#include<stdio.h>
int main()
{
    int compt_matx[6][3] =
    {
        {0 ,4 ,7},
        {1 ,1 ,8},
        {2 ,0 ,9},
        {2 ,3 ,2},
        {3 ,5 ,4},
        {4 ,2 ,3},
    };
    
    
    printf("Compact Matrix:\nRow Column Value\n");               //Displaying Compact Matrices
    for(int i=0 ; i<6 ;i++)
    {	 	  	 	    	   	   	  	 	
        for(int j=0 ; j<3 ;j++)
        {
            printf("%d     ",compt_matx[i][j]);
        }
        printf("\n");
    }
    
    printf("\n");
    
    int row_sparce = compt_matx[5][0] + 1 ;     // Storing the row value Of sparce matrix
    int column_sparce = 0 , a = 0;                 // a is temperory varaible for storing value of column of sparce matrix
    
    for (int i = 0 ; i<6 ;i++)                       // Computing column for sparce matrix
        if(a < compt_matx[i][1])
            a = compt_matx[i][1];
    
    column_sparce = a+1;                        // Storing column Of sparce matrix
    
    int sparce_matrix[row_sparce][column_sparce] ;        // Intializing sparce matrix
     
    for (int i = 0; i < row_sparce; i++)
        for (int j = 0; j < column_sparce; j++)
             sparce_matrix[i][j] = 0;                   //Intializing element of sparce matrix to zero
    
    for(int i=0 ; i<6 ;i++)
    {                                                 //  Storing value of compact matrix as row , column and value.
        int row =0 , column = 0 ,value = 0;
        row = compt_matx[i][0];
        column = compt_matx[i][1];
        value = compt_matx[i][2];
        
        sparce_matrix[row][column] = value;
    }
    
    printf("Sparce Matrix: \n");
    
    for(int i = 0 ; i<row_sparce ; i++)                       // Displaying the sparce matrix.
    {	 	  	 	    	   	   	  	 	
        for(int j =0 ; j<column_sparce;j++)
        {
            printf("%d    ",sparce_matrix[i][j]);
        }
        printf("\n");
    }
    return 0;
}
