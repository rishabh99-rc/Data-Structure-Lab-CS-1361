/*  Registration Number: 201900307 (Rishabh Chauhan)

ALGORITHM :-->

Let, X is an arithmetic expression written in infix notation. This algorithm finds the equivalent postfix expression Y.

Step 1: Start

Step 2: Push “(“ onto the Stack, and add “)” to the end of X.

Step 3: Scan X from left to right and repeat Step 3 to 7 for each element of X until the Stack is empty.

Step 4: If an operand is encountered, add it to Y.

Step 5: If a left parenthesis is encountered, push it onto Stack.

Step 6: If an operator is encountered ,then:

    Step 6.1: Repeatedly pop from Stack and add to Y each operator (on the top of Stack) which has the same precedence as or higher precedence than operator.
    Step 6.2: Add operator to Stack.
    Step 6.3: [End of If]

Step 7: If a right parenthesis is encountered ,then:
    Step 7.1: Repeatedly pop from Stack and add to Y each operator (on the top of Stack) until a left parenthesis is encountered.
    Step 7.2: Remove the left Parenthesis.
    Step 7.3: [End of If]
    Step 7.4: [End of If]

Step 8: Stop.  
*/


#include <stdio.h>
#include <ctype.h>
#define size 50

char stack[size];
int top=-1;
                                
void push(int a)            // Defining the push() function
{	 	  	 	   	      	    	  	 	
    if(top==(size-1))
    printf("the stack is full");
    else
    {
        top++;
        stack[top]=a;
    }
}

char pop()                  // Defining the pop() function
{
    if(top==-1)
    return -1;
    else
    {
        return stack[top--];
    }
}

int pri(char c)
{
    if(c=='^')
    return 3;
    
    else if(c=='/' || c=='*')
        return 2;
    
    else if(c=='+' || c=='-')
        return 1;
    
    else if(c=='(')
        return 0;
}

int main()                      
{	 	  	 	   	      	    	  	 	
    char ar[size];
    char *c,x;
    
    printf("Enter the inflix function: ");
    scanf("%s",ar);
    c=ar;
    while(*c != '\0')                   // Will run untill it reaches the end
    {                           
        if(isalnum(*c))
        printf("%c",*c);
        
        else if(*c=='(')
        push(*c);
        
        else if(*c==')')
        {
            while((x=pop()) != '(')     // In this way it will pop it every time until "(" is found
            {                       
            printf("%c",x);
            }
        }
        
        else
        {
            while(pri(stack[top]) >= pri(*c))
            printf("%c",pop());
            push(*c);
        }
            c++;
    }
    
    while(top!=-1)
    {
        printf("%c",pop());
    }
    
    return 0;
}	 	  	 	   	      	    	  	 	
