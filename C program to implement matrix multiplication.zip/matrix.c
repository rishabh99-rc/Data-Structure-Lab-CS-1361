/* 
Registration No: 201900307 (Rishabh Chauhan)

Step 1: Start
Step 2: Declare row1, col1, row2, col2, i, j, k, sum, mat1[20][20], mat2[20][20], multiply[20][20]
Step 3: Read row1, col1, row2, col2
Step 4: Display “Enter elements of 1st Matrix:”
Step 5: Initialise i=0 and repeat step 6 until ( i<row1 ), ( i <-- i+1 )
Step 6: Initialise j=0 and repeat step 6.1 until ( j<col1 ), ( j <-- j+1 )
	Step 6.1: Store it in mat1[i][j]
Step 7: Display “Enter elements of 2nd Matrix:”
Step 8: Initialise i=0 and repeat step 9 until ( i<row2 ), ( i <-- i+1 )
Step 9: Initialise j=0 and repeat step 9.1 until ( j<col2 ), ( j <-- j+1 )
	Step 9.1: Store it in mat2[i][j]
Step 10: Check if (col1 != row2) 
    Step 10.1: Display "Matrix multiplication is not possible"
Step 11: Else 
    Step 11.1: Initialise i=0 and repeat step 11.2 until (i<row1), (i <-- i+1)
    Step 11.2: Initialise j=0 and repeat step 11.3 until (j<col2), (j <-- j+1)
    Step 11.3: Initialise k=0 and repeat step 11.4 until (k<row2), (k <--k+1)
    Step 11.4: sum <-- sum+ (mat1[i][k] * mat2[k][j])
    Step 11.5: multiply[i][j] <-- sum
    Step 11.6: sum <-- 0
Step 12: Display “Result: ”
Step 13: Initialise i=0 and repeat step 14 until ( i<row1 ), ( i <-- i+1 )
Step 14: Initialise j=0 and repeat step 14.1 & 14.2 until ( j<col2 ), ( j <-- j+1 )
	Step 16.1: Display multiply[i][j] 
	Step 16.2: Display " "
		     Display “ ” 
Step 17: Stop
*/
 
#include<stdio.h>

int main(){
    int row1, col1, row2, col2, i, j, k, sum=0, mat1[20][20],mat2[20][20], multiply[20][20];
    
    //Getting the input of 1st Matrix
    printf("Enter the number of rows & column of 1st Matrix: ");
    scanf("%d%d",&row1, &col1);
    printf("\nEnter the elements of 1st Matrix: ");
    for(i=0; i<row1; i++){	 	  	 	   	      	    	  	 	
        for(j=0; j<col1; j++){
            scanf("%d",&mat1[i][j]);
        }
    }
    
    //Getting the input of 2nd Matrix
    printf("\nEnter the number of rows & column of 2nd Matrix: ");
    scanf("%d%d",&row2, &col2);
    printf("\nEnter the elements of 2nd Matrix: ");
    for(i=0; i<row2; i++){
        for(j=0; j<col2; j++){
            scanf("%d",&mat2[i][j]);
        }
    }
    
    // Check if Matrix Multiplication is possible or not.
    if (col1 != row2){
        printf("\nMatrix multiplication is not possible.");
    }
    
    // Calculation
    else{
        for(i=0; i<row1; i++){
            for(j=0; j<col2; j++){
                for (k=0; k<row2; k++){
                    sum=sum + (mat1[i][k]*mat2[k][j]);
                }
                multiply[i][j]=sum;
                sum=0;
            }
        }
        
        // Printing the result
        printf("Result: ");
        for(i=0; i<row1; i++){
            for(j=0; j<col2; j++){	 	  	 	   	      	    	  	 	
                printf("%d\t",multiply[i][j]);
            printf("\n");
            }
        }
    }
    
    return 0;
}
