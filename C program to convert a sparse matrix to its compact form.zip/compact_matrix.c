/*
 Registration Number - 201900307
 
 ALGORITHM:-->
 STEP 0 : Start
 
 STEP 1 : Declare spare_matrix[6][6]
 
 STEP 2 : Intailize spare_matrix[6][6]
 
 Step 3:  for(i=0 to 6)
        3.1: for(j=0 to 6)
            3.1.1: display spare_matrix[i][j]
 
 STEP 4 : Declare a=0
 
 STEP 5 : for(i=0 to 6)
         5.1 : for(j=0 to 6)
            5.1.1 : if(sparse_matrix[i][j]!=0)
                  5.1.1.1 : temp++
                  
 STEP 6 : Declare compact_matrix[a][3] , flag = 0
 
 STEP 7 : for(i=0 to 6)
         7.1 : for(j=0 to 6)
             7.1.1 : if(sparse_matrix[i][j]!=0)
                    7.1.1.1 : compact_matrix[flag][0] = i.
                    7.1.1.2 : compact_matrix[flag][1] = j.
                    7.1.1.3 : compact_matrix[flag][2] = sparse_matrix[i][j]
                    7.1.1.4 : flag ++
                    
 STEP 8 : Display compact_matrix[a][3]
 
 STEP 9 : Declare transpose_matrices[3][a]
 
 STEP 10 :for(i=0 to a)
         10.1 : for(j=0 to 3)
             10.1.1 : transpose_matrix[j][i] <-- compact_matrix[i][j]
             
 STEP 11 : Display transpose_matrix[temp][3]
 
 STEP 12 : Stop
 */
 
#include<stdio.h>
int main()
{
    int sparse_matrix[6][6] =                             //Declaring sparce matrix
    {
        {1,0,0,0,5,0},
        {0,9,0,0,0,0},
        {3,0,0,2,0,0},
        {0,0,0,0,0,7},
        {0,0,3,0,0,0},
        {0,1,0,0,0,2}
    };
    printf("Sparse Matrix: \n");                        //Displaying the sparse matrix
    for(int i=0; i<6; i++){
        for(int j=0; j<6; j++){
            printf("%d\t",sparse_matrix[i][j]);
        }
        printf("\n");
    }
    
    int a = 0 ;
    
    for(int i = 0 ; i<6 ;i++)                           // counting non- zero element in sparce matrix
        for(int j=0 ; j<6 ; j++)
            if(sparse_matrix[i][j]!=0)
                a++;
    
    int compact_matrix[a][3] , flag = 0;                   // Declaring compact matrix
    
    for(int i = 0 ; i<6 ;i++)
         for(int j=0 ; j<6 ; j++)
            if(sparse_matrix[i][j]!=0)                         // storing value in compact matrix
            {
                compact_matrix[flag][0] = i;
                compact_matrix[flag][1] = j;
                compact_matrix[flag][2] = sparse_matrix[i][j];
                flag ++;
            }
    
    printf("\nCompact Matrix: \n");                            //Displaying compact matrix
    printf("Row\tColumn\tValue \n");
    for(int i = 0 ;i<a ; i++)
    {
        for(int j =0 ; j<3 ;j++)
        {
            printf("%d  \t ",compact_matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    
    //Transpose of Compact Matrices
    
    int transpose_matrix[3][a];
    
    for(int i = 0 ;i<a ; i++)                          // Making transpose of compact matrix
    {	 	  	 	    	   	   	  	 	
        for(int j=0 ; j<3 ;j++)
        {
            transpose_matrix[j][i] =compact_matrix[i][j];
        }
    }
    
    printf("Transpose Of Compact Matrix: \n");
    for (int i =0 ; i<3 ;i++)                                 //Displaying transpose of compact martrix.
    {
        for(int j=0 ;j<a ;j++)
        {
            printf("%d\t",transpose_matrix[i][j]);
        }
        printf("\n");
    }
    return 0;
}

