/*  Registration Number: 201900307(Rishabh Chauhan)

ALGORITHM :-->

Step 1: Start

Step 2: Define MAX as 50        // Maximum number of elements in the queue 

Step 3: Declare a circular_queue[MAX], declare two integer variables front & rear 

Step 4: In void insert(int item):
    Step 4.1: Check if the queue is full, else insert the elements into the array circular_queue[MAX]

Step 5: In void deletion(): 
    Step 5.1: Check if the queue is empty, else delete the element from the front of the queue
    
Step 6: In void display():
    Step 6.1: Check if the queue is empty, else display all the elements of the queue. 
    
Step 7: In int main(): 
    Step 7.1: Declare two integer variables choice & item
    Step 7.2: In the do while loop
    Step 7.3: Using switch case enter the choice of the user.
    Step 7.4: Execute the program as per the entered choice.
    
Step 8: Stop.
*/

#include<stdio.h>
# define MAX 50

int circular_queue[MAX];        // Maximum number of elements in the queue
int front = -1;
int rear = -1;

void insert(int item)           // To insert elements into the queue
{	 	  	 	   	      	    	  	 	
    if((front == 0 && rear == MAX-1) || (front == rear+1))
    {
        printf("Queue Overflow \n");
        return;
    }
    if(front == -1)
    {
        front = 0;
        rear = 0;
    }
    else
    {
        if(rear == MAX-1)
            rear = 0;
        else
            rear = rear+1;
    }
    circular_queue[rear] = item ;
}

void deletion()                 // To delete elements from the queue
{
    if(front == -1)
    {
        printf("\nQueue Underflow\n");
        return ;
    }
    printf("\nElement deleted from queue is : %d\n",circular_queue[front]);
    if(front == rear)
    {
        front = -1;
        rear=-1;
    }
    else
    {
        if(front == MAX-1)
        front = 0;
        else
        front = front+1;
    }	 	  	 	   	      	    	  	 	
}

void display()                  // To display all the elements of the queue
{
    int front_pos = front,rear_pos = rear;
    
    if(front == -1)
    {
        printf("\nQueue is empty\n");
        return;
    }
    printf("\nQueue elements :\n");
    
    if( front_pos <= rear_pos )
    while(front_pos <= rear_pos)
    {
        printf("%d ",circular_queue[front_pos]);
        front_pos++;
    }
    
    else
    {
        while(front_pos <= MAX-1)
        {
            printf("%d ",circular_queue[front_pos]);
            front_pos++;
        }
        front_pos = 0;
        while(front_pos <= rear_pos)
        {
            printf("%d ",circular_queue[front_pos]);
            front_pos++;
        }
    }
    printf("\n");
}	 	  	 	   	      	    	  	 	

int main()
{
    int choice,item;                // Declaring input variables from the user
    do
    {
        printf("\n***** MENU DRIVEN PROGRAM *****");
        printf("\n1.Insert\n");
        printf("2.Delete\n");
        printf("3.Display\n");
        printf("4.Quit\n");
        printf("Enter your choice : ");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1 :
                printf("\nInput the element for insertion in queue : ");
                scanf("%d", &item);
                insert(item);
                break;

            case 2 :
                deletion();
                break;

            case 3:
                display();
                break;

            case 4:
                break;
            
            default:
                printf("Wrong choice\n");
        }
    }while(choice!=4);
    
    return 0;
}	 	  	 	   	      	    	  	 	