/*  Registration Number : 201900307 (Rishabh Chauhan)

ALGORITHM :-->

Step 1: Start

Step 2: Decalre a function DFS(int)     // to implement depth first search
    Step 2.1: In DFS(int i)
    Step 2.2: Use Depth First Search Algo to implement DFS search in graph.
    
    
    
Step 3: In int main():
    Step 3.1: Declare two integer variables i & j 
    Step 3.2: Read the input from the user      // Number of vertices & adjecency matrix
    Step 3.3: visited is initialized to zero
    Step 3.4: Use the DFS() function to implement depth first search
    
Step 4: Stop

*/
#include<stdio.h>
 
void DFS(int);
int G[10][10],visited[10],n;    //n is no of vertices and graph is sorted in array G[10][10]
 
int main()
{
    int i,j;
    printf("Enter number of vertices:");
   
	scanf("%d",&n);
 
    //read the adjecency matrix
	printf("\nEnter adjecency matrix of the graph:");
   
	for(i=0;i<n;i++)
       for(j=0;j<n;j++)
			scanf("%d",&G[i][j]);
 
    //visited is initialized to zero
   for(i=0;i<n;i++)
        visited[i]=0;
 
    DFS(0);
    
    return 0;
}	 	  	 	   	      	    	  	 	
 
void DFS(int i)
{
    int j;
	printf("\n%d",i);
    visited[i]=1;
	
	for(j=0;j<n;j++)
       if(!visited[j]&&G[i][j]==1)
            DFS(j);
}

/*  Expected (Input/Output) :-->

Enter number of vertices:6                                                      
                                                                                
Enter adjecency matrix of the graph:1 0 0 0 0 1                                 
0 0 1 0 1 0                                                                     
0 1 0 0 1 0                                                                     
1 1 1 0 0 0                                                                     
0 0 0 0 1 1                                                                     
1 0 1 0 1 0                                                                     
                                                                                
0                                                                               
5                                                                               
2                                                                               
1                                                                               
4

*/	 	  	 	   	      	    	  	 	
