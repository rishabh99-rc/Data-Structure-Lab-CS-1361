/*  Registration No: 201900307 (Rishabh Chauhan)

ALGORITHM :-->

Step 1: Start

Step 2: Define MAX as 50        // Maximum number of elements in the queue 

Step 3: Declare a linear_queue[MAX], declare two integer variables rear & front 

Step 4: In int main(): 
    Step 4.1: Declare two integer variables choice & item
    Step 4.2: In the while(1)   // loop will go on until exit(1)
    Step 4.3: Using switch case enter the choice of the user.
    Step 4.4: Execute the program as per the entered choice.

Step 5: In void insert(int item):
    Step 5.1: Check if the queue is full, else insert the elements into the array linear_queue[MAX]

Step 6: In int del(): 
    Step 6.1: Check if the queue is empty, else delete the element from the front

Step 7: In int peek():
    Step 7.1: Check if the queue is empty, else return the front element of the queue
    
Step 8: In int isEmpty():
    Step 8.1: Check if the queue is empty
    
Step 9: In int isFull():
    Step 9.1: Check if the queue is full
    
Step 10: In void display():
    Step 10.1: Check if the queue is empty, else display all the elements of the queue. 
    
Step 11: Stop.

*/

#include<stdio.h>
#include<stdlib.h>
#define MAX 50
 
int linear_queue[MAX];
int rear=-1;
int front=-1;
 
void insert(int item);
int del();
int peek();
void display();
int isFull();
int isEmpty();
 
int main()
{	 	  	 	   	      	    	  	 	
        int choice,item;
        while(1)        // Loop will go on until exit(1)
        {
            printf("\n***** MENU DRIVEN PROGRAM *****");
            printf("\n1.Insert\n");
            printf("2.Delete\n");
            printf("3.Display element at the front\n");
            printf("4.Display all elements of the queue\n");
            printf("5.Quit\n");
            printf("\nEnter your choice : ");
            scanf("%d",&choice);
 
            switch(choice)
            {
                case 1:
                    printf("\nInput the element for adding in queue : ");
                    scanf("%d",&item);
                    insert(item);
                    break;
                    
                case 2:
                    item=del();
                    printf("\nDeleted element is  %d\n",item);
                    break;
                        
                case 3:
                    printf("\nElement at the front is %d\n",peek());
                    break;
                        
                case 4:
                    display();
                    break;
                        
                case 5:
                    exit(1);
                        
                default:
                    printf("\nWrong choice\n");
                }   /*End of switch*/
        }   /*End of while*/
 
        return 0;
 
}	 	  	 	   	      	    	  	 	
 
void insert(int item)
{
    if( isFull() )
    {
        printf("\nQueue Overflow\n");
        return;
    }
        
    if( front == -1 )
        front=0;
    rear=rear+1;
    linear_queue[rear]=item ;
}   /*End of insert()*/
 
int del()
{
    int item;
    if( isEmpty() )
    {
        printf("\nQueue Underflow\n");
        exit(1);
    }
    item=linear_queue[front];
    front=front+1;
    return item;
}   /*End of del()*/
 
int peek()
{
    if( isEmpty() )
    {
        printf("\nQueue Underflow\n");
        exit(1);
    }
    return linear_queue[front];
}   /*End of peek()*/
 
int isEmpty()
{	 	  	 	   	      	    	  	 	
    if( front==-1 || front==rear+1 )
        return 1;
    else
        return 0;
}   /*End of isEmpty()*/
 
int isFull()
{
    if( rear==MAX-1 )
        return 1;
    else
        return 0;
}   /*End of isFull()*/
 
void display()
{
    int i;
    if ( isEmpty() )
    {
        printf("\nQueue is empty\n");
        return;
    }
    printf("\nQueue is :\n\n");
    for(i=front;i<=rear;i++)
        printf("%d  ",linear_queue[i]);
    printf("\n\n");
}   /*End of display() */
	 	  	 	   	      	    	  	 	
