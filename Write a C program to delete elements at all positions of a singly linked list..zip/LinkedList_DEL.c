/*
Registration Number : 201900307 (Rishabh Chauhan)

ALGORITHM -->

Step 1 : Start.

Step 2 : Declare a structure with the following details:
        Data Member : 
        Step 1.1 : Declare data.
        Step 1.2 : Structure type pointer varaible link.

Step 3 : Declare a global variable : root of struct pointer type.

Step 4 : Declaring a function length of interger return type to calculate the length of the linkd list.

Step 5 : Decalaring append function to add the node at the last of the linked list.

Step 6 : Declaring a add_at_begin function to add the nid eat the begining of the linked list.

Step 7 : Declaring the add_at_after funcion to add the node after the given location in the linked list.

Step 8 : Decalaring a function to diaplay the nodes of the linked list.

Step 9 : Declaring a function to delete the node of the given location.

Step 10 : Implementing function .

Step 11 : Menu driven program to implement all the function defined by the user.

Step 12 : Stop
*/

#include<stdio.h>
#include<stdlib.h>

struct node     // Declaring a structure 
{
    int data;
    struct node *link;
};

struct node *root = NULL;

int length()    
{
    struct node *temp;
    temp = root;
    int count=0;
    
    while(temp != NULL)
    {	 	  	 	    	   	   	  	 	
        count++;
        temp = temp->link;
    }
    return count;
}

void append()       // To append the elements into the node
{
    struct node *temp;
    temp = (struct node *)malloc(sizeof(struct node));
    printf("Enter Node Data  :: ");
    scanf("%d",&temp->data);
    temp->link = NULL;
    
    if(root == NULL)
        root = temp;
    else
    {
        struct node * flag;
        flag = root;
        while(flag->link!=NULL)
        {
            flag = flag->link;
        }
        flag->link = temp;
    }
}

void add_at_begin()     // To add the elementts into the beginning
{
    struct node *temp;
    temp = (struct node *)malloc(sizeof(struct node));
    printf("Enter Node Data  :: ");
    scanf("%d",&temp->data);
    temp->link = NULL;
    
    if(root == NULL)
        root = temp;
    else
    {	 	  	 	    	   	   	  	 	
        temp->link = root;
        root = temp;
    }
}

void add_at_after(int data)     // To add the elemets in the end 
{
    if(data>length())
    {
        printf("\nInvalid Location\n");
    }
    else
    {
    struct node *temp;
    temp = (struct node *)malloc(sizeof(struct node));
    printf("Enter Node Data  :: ");
    scanf("%d",&temp->data);
    temp->link = NULL;
    
    struct node *flag;
    flag = root;
    int counter =0 ;
        
    while(counter<data-1)
    {
            flag = flag->link;
            counter++;
    }
        temp->link = flag->link;
        flag->link = temp;
    }
}

void display()
{
    printf("\n Linked List  :: ");
    struct node *temp;
    temp = root;
    
    if(temp == NULL)
        printf("Linklist is empty.");
    else
    {	 	  	 	    	   	   	  	 	
        while(temp!= NULL)
        {
            printf("%d-->",temp->data);
            temp = temp->link;
        }
    }
    printf("\n\n");
}

void delete()
{
    int location;
    
    printf("Enter location To Delete :: ");
    scanf("%d",&location);
    location = location+1;
    
    if(location > length())
        printf("\nInvalid Location\n");
    else if(location == 1)
    {
        struct node *temp;
        temp = root;
        root = temp->link;
        temp->link = NULL;
        free(temp);
    }
    else
    {
        struct node *temp = root , *flag;
        int counter=0;
        
        while(counter<location-2)
        {
            temp = temp->link;
            counter++;
        }	 	  	 	    	   	   	  	 	
        flag = temp->link;
        temp->link = flag->link;
        flag->link = NULL;
        free(flag);
    }
}
    

int main()
{
    int choice=0;
    
    while(choice!=6)
    {
        printf("NODE OPERATION \n");
        printf("---------------\n");
        printf("1.Append.\n");
        printf("2.Add_at_Begin.\n");
        printf("3.Add_at_After.\n");
        printf("4.Delete.\n");
        printf("5.Display.\n");
        printf("6.Exit\n");
        
        printf("\nEnter choice :: ");
        scanf("%d",&choice);
        
        switch(choice)
        {
            case 1 : append(); break;
            case 2 : add_at_begin(); break;
            case 3 :
            {
                int data;
                printf("Enter the location after which you want to Add Node :: ");
                scanf("%d",&data);
                add_at_after(data);
            }	 	  	 	    	   	   	  	 	
                break;
            case 4 : delete(); break;
            case 5 : display() ; break;
            case 6 : printf("\n\nThank You\n"); break;
            default : printf("Invalid Input\n");
        }
        printf("\n");
    }
    return 0;
}
