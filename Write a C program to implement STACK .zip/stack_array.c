/* Reg. No: 201900307 (Rishabh Chauhan)

ALGORITHM:--

Step 1: Start

Step 2: Define MAX <-- 50 

Step 3: Declare top, stack[]

Step 4: Initialise top, stack[]

Step 5: Declare the function push(), pop(), peek() & display() 
    
    Step 5.1: In push():
                if(top==MAX-1): Display "Stack is full"
                else: Display "Enter element to push"
                      top <-- top+1
                      stack[top] <-- val
                      
    Step 5.2: In pop():
                if(top==-1): Display "Stack is empty ! !"
                else: Display "Deleted element is",stack[top]
                      top <-- top-1
                      
    Step 5.3: In peek():
                if(top==-1): return -1
                else: return stack[top]
                
    Step 5.4: In display():
                if(top==-1): Display "Stack is empty ! !"
                else: Display "Stack is"
                      for(i=top; i>=0; i--): Diaplay "stack[i]"

Step 6: Display the Stack Menu 

Step 7: Ask the choice from the user

Step 8: Using switch case perform any one of the declared function

Step 9: Stop

*/

#include<stdio.h>
#include<stdlib.h>

#define MAX 50	//Maximum number of elements that can be stored

int top=-1,stack[MAX];
void push();
void pop();
int peek();
void display();

int main()
{	 	  	 	   	      	    	  	 	
	int ch;

	while(1)	//infinite loop, will end when choice will be 4
	{
		printf("\n*** Stack Menu ***");
		printf("\n\n1.Push\n2.Pop\n3.Display\n4.Peek\n5.Exit");
		printf("\n\nEnter your choice(1-5):");
		scanf("%d",&ch);

		switch(ch)
		{
			case 1: push();
					break;
			case 2: pop();
					break;
			case 3: display();
					break;
			case 4: printf("The top of the stack = %d", peek());
			        break;
			case 5: exit(0);

			default: printf("\nWrong Choice!!");
		}
	}
	return 0;
}

void push()             // Declaring the push function
{
	int val;

	if(top==MAX-1)
	{
		printf("\nStack is full!!");
	}
	else
	{	 	  	 	   	      	    	  	 	
		printf("\nEnter element to push:");
		scanf("%d",&val);
		top=top+1;
		stack[top]=val;
	}
}

void pop()              // Declaring the pop function
{
	if(top==-1)
	{
		printf("\nStack is empty!!");
	}
	else
	{
		printf("\nDeleted element is %d",stack[top]);
		top=top-1;
	}
}

int peek()              // Declaring the peek function
{
    if (top==-1){
        return -1;
    }
    
    else{
        return stack[top];
    }
}

void display()          // Declaring the display function
{
	int i;

	if(top==-1)
	{	 	  	 	   	      	    	  	 	
		printf("\nStack is empty!!");
	}
	else
	{
		printf("\nStack is...\n");
		for(i=top;i>=0;--i)
			printf("%d\n",stack[i]);
	}
}
