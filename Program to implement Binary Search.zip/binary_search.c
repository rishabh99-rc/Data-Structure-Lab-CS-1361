/* Reg No: 201900307

Step 1: Start

Step 2: Define a function swap() to swap to munbers

Step 3: Declare n,s,g,arr[n]

Step 4: Read n,s,g

Step 5: Repeat step 6 & 7 upto a<n, start a=0

Step 6: Read arr[a]

Step 7: a <-- (a+1)

Step 8: Initialize x=0 and repeat Step 9 until x<(n-1)

Step 9: Initialize f=0 and repeat Step 9.1 & 9.2 until f<(n-1)

    Step 9.1: if(arr[f]>arr[f+1])
    Step 9.2: swap 
              t <-- arr[f]
              arr[f] <-- arr[f+1]
              arr[f+1] <-- t
              
Step 10: Declare low=0, high=n-1, mid=(low+high)/2, found=0

Step 11: while(high>=low)
    
    Step 11.1: mid <-- (low+high)/2
    Step 11.2: if(arr[mid]<s)
               low <-- (mid+1)
    Step 11.3: else if(arr[mid]>s)
               high <-- (mid-1)
    Step 11.4: else if(arr[mid]==s)
               found <-- found+1, break
               
Step 12: If (found>0) goto step 13, else goto step 14

Step 13: Display ("The element s is found !"), goto step 15

Step 14: Display ("Not Found! s isn't present in the list")

Step 15: Stop

*/

#include <stdio.h>
void swap(int *a, int *b){	 	  	 	   	      	    	  	 	
    int t=0;
    t=*a;
    *a=*b;
    *b=t;
}

int main(){
    int n,s,g;
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int arr[n];
    
    for(int a=0; a<n; a++){
    scanf("%d",&arr[a]);
    }
    
    for(int x=0; x < n-1; x++){
        
        for(int f=0; f < n-1; f++){
            if(arr[f] > arr[f+1]){
                swap(&arr[f], &arr[f+1]);
            }
        }
    }

    int low=0, high=n-1, found=0, mid;
    printf("Enter the element to be searched: ");
    scanf("%d",&s);
    
    printf("The sorted list is \n");
    for (g=0; g<n; g++){
        printf("%d ",arr[g]);
    }
    
    while(low<=high){	 	  	 	   	      	    	  	 	
        mid=(high+low)/2;
        if(s>arr[mid]){
            low=mid+1;
        }
        else if(s<arr[mid]){
            high=mid-1;
        }
        else if(s==arr[mid]){
            printf("\nThe element %d is found !",s);
            found=1;
            break;
        }
    }
  
    if (found==0)
        printf("\nNot found! %d isn't present in the list ", s);

  return 0;
}