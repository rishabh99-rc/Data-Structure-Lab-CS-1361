/*  Registration Number: 201900307 (Rishabh Chauhan)

ALGORITHM :-->

Here A <-- Top element;  B <-- Next to Top element

Step 1: Start

Step 2: Add ")" to the postfix expression.

Step 3: Read postfix expression Left to Right until ) encountered

Step 4: If operand is encountered, push it onto Stack
        [End If]

Step 5: If operator is encountered, Pop two elements
    
    Step 5.1: A -> Top element
    Step 5.2: B -> Next to Top element
    Step 5.3: Evaluate B operator A
    Step 5.4: push B operator A onto Stack

Step 6: Set result = pop

Step 7: Stop
*/

#include <stdio.h>
#include <ctype.h>
#include <math.h>
#define size 50

char stack[size];
int top=-1;

void push(char c)       // Declaring the push function() 
{	 	  	 	   	      	    	  	 	
    if(top==(size-1))
    printf("the stack is full");
    else
    {
        top++;
        stack[top]=c;
    }
}

int pop()               // Declaring the pop function()
{
    if(top==-1)
    return 0;
    
    else 
    return stack[top--];
}

int main()
{
    char out[size];
    char *c;
    int x,y,z,n;
    
    printf("********** EVALUATION OF A GIVEN POSTFIX EXPRESSION **********\n");
    printf("\nEnter a valid postfix expression\n(combination of numbers and operators): \n");
    scanf("%s",out);
    c=out;
    
    while(*c != '\0')   
    {
        if(isdigit(*c))
        {
            n=*c-48;
            push(n);
        }	 	  	 	   	      	    	  	 	
        
        else if(*c == '+')
        {
            y=pop();
            z=pop();
            x=z+y;
            push(x);
        }
        
        else if(*c == '-')
        {
            y=pop();
            z=pop();
            x=z-y;
            push(x);
        }
        
        else if(*c == '*')
        {
            y=pop();
            z=pop();
            x=z*y;
            push(x);
        }
        
        else if(*c == '/')
        {
            y=pop();
            z=pop();
            x=z/y;
            push(x);
        }
        c++;
    }
    
    while(top != -1)
    {	 	  	 	   	      	    	  	 	
        printf("%d",stack[top]);
        top--;
    }
    
    return 0;
}