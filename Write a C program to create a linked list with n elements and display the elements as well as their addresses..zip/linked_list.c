/*  Registration Number:-201900307(Rishabh Chauhan)

ALGORITHM :-->
Step 1: Start
 
Step 2: Declare a structure as node:
    Step 2.1: Declare integer variable as data & a pointer *next
 
Step 3: Declare a function void create(int n)  // To get the input from the user in the node
 
Step 4: Declare a function void display()  // To display the input from the node
 
Step 5: In the main function: (three choices using switch case)
        Step 5.1: To make a list with desired size.
        Step 5.2: To Display the list.
        Step 5.3: Exit The Function.

Step 6: If 1 selected go to step 3.

Step 7: If 2 selected go to step 4.

Step 8: If 3 selected go to step 9.

Step 9: Stop
*/

#include<stdio.h>
#include<stdlib.h>

struct node
{
    int data;
    struct node *next;
}*ptr;

void create(int n)              // Take input from the user for the node
{
    struct node *front,*tmp;
    int num,i;
    ptr=(struct node *)malloc(sizeof(struct node));
    if(ptr==NULL)
    {
        printf("Sorry Memory Full");
    }
    else
    {
        printf("Input Data for Node 1:-");
        scanf("%d",&num);
        ptr->data=num;
        ptr->next=NULL;
        tmp=ptr;
        
        for(i=2;i<=n;i++)
        {	 	  	 	    	  	   	      	 	
            front=(struct node *)malloc(sizeof(struct node));
            
            if(front==NULL)
            {
                printf("Memory can't be allocated!");
                break;
            }
            
            else
            {
                printf("Enter Data For Node %d:-",i);
                scanf("%d",&num);
                front->data=num;
                front->next=NULL;
                tmp->next=front;
                tmp=tmp->next;
            }
        }
    }
}

void display()          // Display the output of the node
{
    int i=1;
    struct node *tmp;
    
    if(ptr==NULL)
    {
        printf("I am Empty");
    }
    
    else
    {
        tmp=ptr;
        
        while(tmp!=NULL)
        {
            printf("\tNode:-%d\n \tData:-%d\n \tAdress:-%p\n",i,tmp->data,tmp);
            tmp=tmp->next;
            i++;
            printf("\n");
        }	 	  	 	    	  	   	      	 	
    }
}

int main()
{
    int c,n;
    do
    {
        printf("***** LINKED LIST *****");
        printf("\n1-Create and Enter Value in Node \n2-Display List \n3-Exit\n:-");
        scanf("%d",&c);
        switch(c)
        {
            case 1:printf("\nEnter Size of List:-");
                scanf("%d",&n);
                create(n);
                break;
        
            case 2:printf("\nData Entered in list:-\n");
                display();
                break;
        
            case 3:printf("Thank You");
                break;
        
            default:printf("Entered Wrong Option");
        }
    }while(c!=3);
    
    return 0;
}