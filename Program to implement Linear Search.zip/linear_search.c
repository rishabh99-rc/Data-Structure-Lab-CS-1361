/* Registration No: 201900307

Algorithm:

Step 1: Start

Step 2: Declare a[20],i,x,n

Step 3: Display ("Enter the number of elements:")

Step 4: Read n

Step 5: Repeat step 6 & 7 until (i<n)

Step 6: Read a[i]

Step 7: i <-- (i+1)

Step 8: Display "Enter the element to be searched:"

Step 9: Read x

Step 10: Repeat step 11 & 12 until (i<n)

Step 11: If(a[i]==x)

    Step 11.1: Display ( "The element x is found at position (i+1)" )
               else
    Step 11.2: Display ("Element not found")
    
Step 12: i <-- (i+1)

Step 13: Stop

*/

#include<stdio.h>
  
int main()
{	 	  	 	   	      	    	  	 	
    int a[20],i,x,n;
    printf("Enter the number of elements: ");
    scanf("%d",&n);
     
    for(i=0;i<n;++i)
        scanf("%d",&a[i]);
     
    printf("\nEnter the element to searched:");
    scanf("%d",&x);
     
    for(i=0;i<n;++i)
        if(a[i]==x)
            break;
     
    if(i<n)
        printf("The element %d is found at position %d",x,(i+1));
    else
        printf("Element not found");
  
    return 0;
}