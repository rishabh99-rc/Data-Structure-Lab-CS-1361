/*  Registration No: 201900307 (Rishabh Chauhan)

Step 1: Start.

Step 2: We declare a structure having an integer variable (data) and two struct node pointers (right and left respectively).

Step 3: Inside struct node *newNode(int data):
        •Dynamically allot memory to struct node by
        struct node* t----->(struct node*)malloc(sizeof(struct node)).
        •Then data is assigned to t->data.
        •NULL is assigned to left and right parts respectively.

Step 4: Inside struct node* insert(struct node* node, int data):
        •if node==NULL then we return data.
        •else we recursively call insert while assigning it to node-> left and node->right respectively.
        •We ultimately return the node.
        
Step 5: Inside int height(struct node* ptr):
        •If ptr==NULL then 0 is returned.
        •int hlf----->height(ptr->left).
        •int hrt----->height(ptr->right).
        •if hlf>hrt then 1+hlf is returned else 1+hrt.
        
Step 6: Inside int isAVL(struct node *ptr):
        •if ptr==NULL then 1 is returned.
        •int hl----->height(ptr->left).
        •int hr=height(ptr->right).
        •int difference= hl>hr? (hl-hr):(hr-hl).
        •1 is returned if difference<=1 && isAVL(ptr->left) && isAVL(ptr->right).
        
Step 7: Inside main():
        •Data is accepted from the user.
        •The above functions are called accordingly.
        
Step 8: Stop       
*/

#include<stdio.h>
#include<stdlib.h>

struct node
{	 	  	 	   	      	    	  	 	
   int data;
   struct node *left;
   struct node *right;
};

struct node* newnode (int in)
{
    struct node *temp;

    temp = (struct node *) malloc (sizeof(struct node));

    temp->data = in;
    temp->left = NULL;
    temp->right = NULL;

    return temp;
}

struct node* insert (struct node *root, int in)
{
    if (root==NULL)
    {
        return newnode (in);
    }
        else if (in>root->data)
        {
            root->right = insert (root->right, in);
        }
            else
            {
                root->left = insert (root->left, in);
            }

    return root;
}


void inorder (struct node* NODE)
{	 	  	 	   	      	    	  	 	
    if (NODE==NULL)
    {
        return;
    }

    inorder (NODE->left);
    printf ("%d ", NODE->data);
    inorder (NODE->right);
}

int height (struct node *root)
{
    int left=0, right=0;

    if (root==NULL)
    {
        return 0;
    }

    left=height (root->left);
    right=height (root->right);

    if (left>right)
    {
        return left+1;
    }
    else
    {
        return right+1;
    }
}

int Balanced (struct node *root)
{
    int lft_ht, rt_ht;

    if (root==NULL)
    {	 	  	 	   	      	    	  	 	
        return 1;
    }

    lft_ht=height (root->left);
    rt_ht=height (root->right);

    if( abs(lft_ht-rt_ht)<=1 && Balanced (root->left) && Balanced (root->right) )
    {
        return 1;
    }

    return 0;
}

int main()
{
    int n, input, flag=1, flg=1, dis;
    struct node *root=NULL;

    while (flag==1)
    {
        printf ("\nSelect the action to be performed:- \n 1. Insertion of a node in a Binary Search Tree \n 2. Display the Binary Search Tree \n 3. Check if the Binary Search Tree is Balanced or not \n 4. Exit \nSelection: ");
        scanf ("%d", &n);

        switch (n)
        {
            case 1: printf ("\nEnter the number to be inserted in the Binary Search Tree: ");
                    scanf ("%d", &input);
                    root=insert (root, input);
                    break;

            case 2: if (root==NULL)
                    {
                        printf ("\nBinary Search Tree is empty. \n");
                    }
                    else
                    {	 	  	 	   	      	    	  	 	
                        printf ("\n");
                        inorder (root);
                        printf ("\n");
                    }
                    break;

            case 3: if (root==NULL)
                    {
                        printf ("\nBinary Search Tree is empty. \n");
                    }
                    else
                    {
                        if ( Balanced (root) )
                        {
                            printf ("\nThe Binary Search Tree is balanced. \n");
                        }
                        else
                        {
                            printf ("\nThe Binary Search Tree is not balanced. \n");
                        }
                    }
                    break;

            case 4: printf ("\nProgram Exited. \n");
                    flag=0;
                    break;

            default:    printf ("\nInvalid Selection. Please try again. \n");
                        break;
        };
    }

    return 0;
}

/*  Expected (Input/Output)
                                                                                
Select the action to be performed:-                                             
 1. Insertion of a node in a Binary Search Tree                                 
 2. Display the Binary Search Tree                                              
 3. Check if the Binary Search Tree is Balanced or not                          
 4. Exit                                                                        
Selection: 1                                                                    
                                                                                
Enter the number to be inserted in the Binary Search Tree: 30                   
                                                                                
Select the action to be performed:-                                             
 1. Insertion of a node in a Binary Search Tree                                 
 2. Display the Binary Search Tree                                              
 3. Check if the Binary Search Tree is Balanced or not                          
 4. Exit                                                                        
Selection: 1                                                                    
                                                                                
Enter the number to be inserted in the Binary Search Tree: 40                   
                                                                                
Select the action to be performed:-                                             
 1. Insertion of a node in a Binary Search Tree                                 
 2. Display the Binary Search Tree                                              
 3. Check if the Binary Search Tree is Balanced or not                          
 4. Exit                                                                        
Selection: 1                                                                    
                                                                                
Enter the number to be inserted in the Binary Search Tree: 50                   
                                                                                
Select the action to be performed:-                                             
 1. Insertion of a node in a Binary Search Tree                                 
 2. Display the Binary Search Tree                                              
 3. Check if the Binary Search Tree is Balanced or not                          
 4. Exit                                                                        
Selection: 2                                                                    
                                                                                
30 40 50                                                                        
                                                                                
Select the action to be performed:-                                             
 1. Insertion of a node in a Binary Search Tree                                 
 2. Display the Binary Search Tree                                              
 3. Check if the Binary Search Tree is Balanced or not                          
 4. Exit   
Selection: 3                                                                    
                                                                                
The Binary Search Tree is not balanced.                                         
                                                                                
Select the action to be performed:-                                             
 1. Insertion of a node in a Binary Search Tree                                 
 2. Display the Binary Search Tree                                              
 3. Check if the Binary Search Tree is Balanced or not                          
 4. Exit  

*/	 	  	 	   	      	    	  	 	
